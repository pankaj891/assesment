package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import com.example.demo.constant.AssesmentConstant;
import com.example.demo.exception.ExchangeRateException;
import com.example.demo.exception.InternalServerException;
import com.example.demo.rest.IAssesmentrest;

@SpringBootTest
@ActiveProfiles("prod")
class AssesmentoneApplicationTests {

	@Value("${is_exchange_rate_enable_prod}")
	private String IS_EXCHANGE_ENABLE;

	@Autowired
	private IAssesmentrest assementRest;

	@Test
	void testGetTimeStamp() {
		Map<String, String> timeStamp = assementRest.getTimeStamp();
		assertEquals(timeStamp.get(AssesmentConstant.TIMESTAMP_RESPONSE),
				timeStamp.get(AssesmentConstant.TIMESTAMP_RESPONSE));
	}

	@Test
	void testGetExchangeRate() throws ExchangeRateException, InternalServerException {

		if (IS_EXCHANGE_ENABLE != null && !IS_EXCHANGE_ENABLE.isEmpty()
				&& IS_EXCHANGE_ENABLE.equals(AssesmentConstant.TRUE)) {
			Double exchangeRate = assementRest.getExchangeRate();
			assertEquals(1.0052390267824, exchangeRate);
		} else {
			Double exchangeRate = assementRest.getExchangeRate();
			assertEquals(1.1,exchangeRate);
		}
	}

}
