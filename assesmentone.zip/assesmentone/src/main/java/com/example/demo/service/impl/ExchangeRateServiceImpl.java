package com.example.demo.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.demo.constant.AssesmentConstant;
import com.example.demo.exception.ExchangeRateException;
import com.example.demo.exception.InternalServerException;
import com.example.demo.service.IExchangeRateService;

@Service
public class ExchangeRateServiceImpl implements IExchangeRateService {

	@Value("${is_exchange_rate_enable_prod}")
	private String IS_EXCHANGE_ENABLE;

	@Override
	public Double getExchangeRate() throws ExchangeRateException, InternalServerException {
		// TODO Auto-generated method stub
		try {
			if (IS_EXCHANGE_ENABLE != null && !IS_EXCHANGE_ENABLE.isEmpty() && AssesmentConstant.TRUE.equals(IS_EXCHANGE_ENABLE)) {
				RestTemplate restTemplate = new RestTemplate();
				Map<String, Map<String, Object>> forObject = restTemplate.getForObject(AssesmentConstant.URI,
						Map.class);
				if (forObject != null && forObject.get(AssesmentConstant.USD) != null
						&& forObject.get(AssesmentConstant.USD).get(AssesmentConstant.USD_RATE) != null) {
					return Double
							.valueOf(forObject.get(AssesmentConstant.USD).get(AssesmentConstant.USD_RATE).toString());
				} else
					throw new ExchangeRateException("Exchange Rate Not Found!!!");
			}
		} catch (ExchangeRateException ex) {
			throw ex;
		} catch (Exception ex) {
			throw new InternalServerException("Internal Server Error!!!");
		}
		return 1.1;
	}

}
