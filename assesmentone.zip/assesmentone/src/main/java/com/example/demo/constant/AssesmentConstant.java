package com.example.demo.constant;

public interface AssesmentConstant {

	public static String TIMESTAMP_RESPONSE = "timestamp";
	
	public static String URI = "http://www.floatrates.com/daily/EUR.json";
	
	public static String USD = "usd";
	
	public static String USD_RATE = "rate";
	
	public static String TRUE = "true";
}

