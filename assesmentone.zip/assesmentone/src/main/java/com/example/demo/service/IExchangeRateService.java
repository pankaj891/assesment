package com.example.demo.service;

import com.example.demo.exception.ExchangeRateException;
import com.example.demo.exception.InternalServerException;

public interface IExchangeRateService {

	public Double getExchangeRate() throws ExchangeRateException, InternalServerException;
}
