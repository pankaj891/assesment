package com.example.demo.exception;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class ControllerAdvisor extends ResponseEntityExceptionHandler {

	private ResponseEntity<Object> toResponseEntity(Exception exception, WebRequest request, String bodyOfResponse,
			HttpStatus status) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Exception-Type", exception.getClass().getName());
		return this.handleExceptionInternal(exception, bodyOfResponse, headers, status, request);
	}

	@ExceptionHandler(ExchangeRateException.class)
	public ResponseEntity<Object> handleExchangeRateException(ExchangeRateException exception, WebRequest request) {
		return this.toResponseEntity(exception, request, exception.getMessage(), HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(InternalServerException.class)
	public ResponseEntity<Object> handleInternalServerException(InternalServerException exception, WebRequest request) {
		return this.toResponseEntity(exception, request, exception.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
