package com.example.demo.rest;

import java.util.Map;

import com.example.demo.exception.ExchangeRateException;
import com.example.demo.exception.InternalServerException;

public interface IAssesmentrest{

	public Map<String,String> getTimeStamp();
	
	public Double getExchangeRate() throws ExchangeRateException, InternalServerException;
}
