package com.example.demo.rest.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.constant.AssesmentConstant;
import com.example.demo.exception.ExchangeRateException;
import com.example.demo.exception.InternalServerException;
import com.example.demo.rest.IAssesmentrest;
import com.example.demo.service.IExchangeRateService;

@RestController
public class AssesmentRestImpl implements IAssesmentrest {

	@Autowired
	private IExchangeRateService iExchangeRateService;

	/**
	 * Gets the TimeStamp.
	 * 
	 * @return Map
	 */
	@Override
	@RequestMapping(path = "/timestamp", method = RequestMethod.GET)
	public Map<String, String> getTimeStamp() {
		// TODO Auto-generated method stub
		Map<String, String> put = new HashMap<>();
		put.put(AssesmentConstant.TIMESTAMP_RESPONSE, String.valueOf(new Date().getTime()));
		return put;
	}

	/**
	 * @return Double (Exchange Rate EURO to USD)
	 */
	@Override
	@RequestMapping(path = "/exchangerate", method = RequestMethod.GET)
	public Double getExchangeRate() throws ExchangeRateException, InternalServerException {
		// TODO Auto-generated method stub
		return iExchangeRateService.getExchangeRate();
	}

}
