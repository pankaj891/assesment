package com.associate;

public class AppRunner {

	public static void main(String[] args) {
		Problems problem = new Problems();
		// Problem 1 test case
		System.out.println("Problem 1 : " + problem.digitCount(-7921));
		System.out.println("Problem 1 : " + problem.digitCount(-7921));

		// Problem 3 test case
		System.out.println("Problem 3 : " + problem.maxNumber(234, 122));
		System.out.println("Problem 3 : " + problem.maxNumber(-567, -456));

		// Problem 4 test case
		System.out.println("Problem 4 : " + problem.getMedianOfSortedArray(new Double[] { 10.7 }));
		System.out.println("Problem 4 : "
				+ problem.getMedianOfSortedArray(new Double[] { -957.0, -493.0, -384.0, -268.0, -131.0 }));

		// Problem 6 test case
		System.out.println("Problem 6 : " + problem.countVowels("Sunshine"));
		System.out.println("Problem 6 : " + problem.countVowels("Major"));

		// Problem 10 test case
		System.out.println("Problem 10 : " + problem.secondLargestNumber(new Integer[] { 23, 12, 45, 22, 56, 45, 78 }));
		System.out.println(
				"Problem 10 : " + problem.secondLargestNumber(new Integer[] { 23, 12, -45, 22, 56, 45, 99, 100 }));

		// Problem 5 test case
		System.out.println("Problem 5 : " + problem.taxDeduction(190000L));
		System.out.println("Problem 5 : " + problem.taxDeduction(2400000L));

		// Problem 8 test case
		System.out.println("Problem 8 : " + problem.convertSecToDay(21893872));
		System.out.println("Problem 8 : " + problem.convertSecToDay(null));

		// Problem 9 test case
		System.out.println("Problem 9 : " + problem.specialTwoDigit(59));
		System.out.println("Problem 9 : " + problem.specialTwoDigit(78));

		// Problem 2 test case
		System.out.println("Problem 2 : " + problem.grossPriceBeforeTax(99.95, 0.12));
		System.out.println("Problem 2 : " + problem.grossPriceBeforeTax(45.00, 0.00));

		// Problem 7 test case
		System.out.println("Problem 7 : " + problem.findCompoundInflation(1.2, 5));
		System.out.println("Problem 7 : " + problem.findCompoundInflation(3.0, 3));

	}
}
