package com.associate;

import java.util.Arrays;

public class Problems {

	// problem1
	public Integer digitCount(Integer number) {
		if (number == null)
			return 0;
		return String.valueOf(Math.abs(number)).length();
	}

	// problem 3
	public Integer maxNumber(Integer num1, Integer num2) {
		if (num1 == null || num2 == null)
			return null;
		return (num1 >= num2 ? num1 : num2);
	}

	// problem 4
	public Double getMedianOfSortedArray(Double[] sortedArray) {
		Double median = null;
		if (sortedArray == null || sortedArray.length == 0)
			return median;
		Integer arrayLength = sortedArray.length;
		if (arrayLength % 2 == 0)
			return (sortedArray[(arrayLength / 2) - 1] + sortedArray[arrayLength / 2]) / 2.0;
		else
			return sortedArray[arrayLength / 2];
	}

	// problem6
	public Integer countVowels(String input) {
		if (input == null || input.length() == 0)
			return 0;
		Integer counter = 0;
		Integer vowelCount = 0;
		Integer len = input.length();
		while (counter < len) {
			if (isVowel(input.charAt(counter)))
				vowelCount++;
			counter++;
		}
		return vowelCount;
	}

	public Boolean isVowel(Character charac) {
		if ((charac == 'a' || charac == 'A') || (charac == 'e' || charac == 'E') || (charac == 'i' || charac == 'I')
				|| (charac == 'o' || charac == 'O') || (charac == 'u' || charac == 'U'))
			return true;
		return false;
	}

	// problem 10
	public Integer secondLargestNumber(Integer[] arr) {
		if (arr == null || arr.length == 0)
			return null;
		Arrays.sort(arr);
		return (arr.length == 1 ? arr[0] : arr[arr.length - 2]);
	}

	// problem 5
	public Long taxDeduction(Long income) {
		if (income == null)
			return -1L;
		if (income <= 250000L) {
			System.out.println("hello");
			return 0L;
		}
		else if (income > 250000L && income <= 500000L)
			return (long) (0.1 * (income - 250000));
		else if (income > 500000L && income <= 1000000L)
			return (long) (0.1 * (500000 - 250000) + 0.2 * (income - 500000));
		else
			return (long) (0.1 * (500000 - 250000) + 0.2 * (1000000 - 500000) + 0.3 * (income - 1000000));
	}

	//problem 8
	public String convertSecToDay(Integer sec) {
		if (sec == null)
			return "Invalid Input";
		Integer day = sec / (24 * 3600);
		sec = sec % (24 * 3600);
		Integer hour = sec / 3600;
		sec %= 3600;
		Integer minutes = sec / 60;
		sec %= 60;
		Integer seconds = sec;
        return day + " " + "Day(s) " + hour
                + " " + "Hour(s) " + minutes + " "
                + "Minute(s) " + seconds + " "
                + "Second(s) ";
	}
	
	//problem 9
	public String specialTwoDigit(Integer input) {
		int num = input;
        int count = 0, digitSum = 0, digitProduct = 1;
        
        while (num != 0) {
            int digit = num % 10;
            num /= 10;
            digitSum += digit;
            digitProduct *= digit;
            count++;
        }
     
        if (count != 2)
            return "Invalid input, please enter a 2-digit number";
        else if ((digitSum + digitProduct) == input)
            return "Special 2-digit number";
        else
            return "Not a special 2-digit number";
	}
	
	//problem 2
	public double grossPriceBeforeTax(double netPrice,double taxRate){
        return Math.round(netPrice/(1+taxRate) * 100.0) / 100.0;    
    }
	
	//problem 7
	public static double findCompoundInflation(double inflationRateInPercentage,double years){
        double inflationRate= inflationRateInPercentage/100; 
        double actualPrice=inflationRate+1;
        double totalActualPrice=Math.pow(actualPrice,years);
        double compoundInflation=totalActualPrice-1; 
        double compoundInflationPercentage=compoundInflation*100;
        return Math.round(compoundInflationPercentage*100.0)/100.0;
      }

}
